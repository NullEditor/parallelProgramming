#include<iostream>
#include <pthread.h>
#include<semaphore.h>
#include<sys/time.h>
#include<unistd.h>
#include <fstream>
#include<sstream>
using namespace std;
typedef struct {
	 int t_id; //线程 id
}threadParam_t;

//信号量定义
pthread_barrier_t sem_Divsion;
pthread_barrier_t sem_Elimination;
timeval tv_begin,tv_end;//record start and end time
//常量
int n;
double** ma;
int NUM_THREADS = 10;//线程数
void* threadFunc(void* param) {
	threadParam_t* p = (threadParam_t*)param;
	int t_id = p->t_id;

	for (int k = 0; k < n; k++) {
		if (t_id == 0) {
			for (int j = k + 1; j < n; j++) {
				ma[k][j] = ma[k][j] / ma[k][k];

			}
			ma[k][k] = 1;
		}
		//大家一起等id=0的线程做完除法
		pthread_barrier_wait(&sem_Divsion);
		//各自开始干活
		for(int i = k+1;i<n;i++){
			for(int j = k+1+t_id;j<n;j+=NUM_THREADS){//在这里分
				ma[i][j] = ma[i][j] - ma[i][k] * ma[k][j];
			}
			ma[i][k]=0;
		}
		pthread_barrier_wait(&sem_Elimination);
	
	}
	pthread_exit(NULL);
}
void fileInit(){
	ifstream file;
	file.open("data.txt");
	 if (! file.is_open())
   	 { cout << "Error opening file"; exit (1); }
   	 cout<<"openFile"<<endl;
   	char num[256];
   	file.getline(num,256);
   	stringstream ss(num);
   	ss>>n; 
   	cout<<n<<endl;
	ma = new double*[n];
		for(int i=0;i<n;i++){
		ma[i] = new double[n];
	}
	for(int i=0;i<n;i++){
		char line[1000];
		file.getline(line,1000);
		stringstream ss(line);
		for(int j=0;j<n;j++){
			ss>>ma[i][j];
		}
	}
	file.close();
}
void cinInit(){
	cin>>n;
	ma = new double*[n];
	for(int i=0;i<n;i++){
		ma[i] = new double[n];
	}
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++){
		cin>>ma[i][j];
		}
}
int main() {
	fileInit();
	gettimeofday(&tv_begin,NULL);
	pthread_barrier_init(&sem_Divsion, NULL,NUM_THREADS);
	pthread_barrier_init(&sem_Elimination, NULL, NUM_THREADS);

	pthread_t handles[NUM_THREADS];// 创建对应的 Handle
	threadParam_t param[NUM_THREADS];// 创建对应的线程数据结构
	for (int t_id = 0; t_id < NUM_THREADS; t_id++) {
		param[t_id].t_id = t_id;
		pthread_create(&handles[t_id],NULL,threadFunc,&param[t_id]);
	}
	for (int t_id = 0; t_id < NUM_THREADS; t_id++) {
		pthread_join(handles[t_id],NULL);
	}
	pthread_barrier_destroy(&sem_Divsion);
	pthread_barrier_destroy(&sem_Elimination);
	        gettimeofday(&tv_end,NULL);
		for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
		cout<<ma[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<"time:"<<(tv_end.tv_sec - tv_begin.tv_sec)<<endl; 
}
