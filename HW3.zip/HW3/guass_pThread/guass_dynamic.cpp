#include<iostream>
#include <pthread.h>
#include <unistd.h>
#include<sys/time.h>
#include <fstream>
#include<sstream>
using namespace std;
typedef struct {
	int k;
	int t_id;
}threadParam_t;

int n;//在这里设置矩阵规模
double** ma;
timeval tv_begin,tv_end;//record start and end time
void* threadFunc(void* param) {
	threadParam_t* p = (threadParam_t*)param;
	int k = p->k;
	int t_id = p->t_id;
	int i = k + t_id + 1;

	for (int j = k + 1; j < n; j++) {
		ma[i][j] = ma[i][j] - ma[j][k] * ma[k][j];
	}
	ma[i][k] = 0;
	pthread_exit(NULL);
}
void cinInit(){
	cin>>n;
	ma = new double*[n];
	for(int i=0;i<n;i++){
		ma[i] = new double[n];
	}
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++){
		cin>>ma[i][j];
		}
}
void fileInit(){
	ifstream file;
	file.open("data.txt");
	 if (! file.is_open())
   	 { cout << "Error opening file"; exit (1); }
   	 cout<<"openFile"<<endl;
   	char num[256];
   	file.getline(num,256);
   	stringstream ss(num);
   	ss>>n; 
   	cout<<n<<endl;
	ma = new double*[n];
		for(int i=0;i<n;i++){
		ma[i] = new double[n];
	}
	for(int i=0;i<n;i++){
		char line[1000];
		file.getline(line,1000);
		stringstream ss(line);
		for(int j=0;j<n;j++){
			ss>>ma[i][j];
		}
	}
	file.close();
}
int main() {
	fileInit();
	gettimeofday(&tv_begin,NULL);
	for (int k = 0; k < n; k++) {
		for (int j = k + 1; j < n; j++) {
			ma[k][j] = ma[k][j] / ma[k][k];
		}
		ma[k][k] = 1;
	int worker_count = n - 1 - k;
	pthread_t* handles = new pthread_t[worker_count];
	threadParam_t* param = new threadParam_t[worker_count];

	for (int t_id = 0; t_id < worker_count; t_id++) {
		param[t_id].k = k;
		param[t_id].t_id = t_id;
	}

	for (int t_id = 0; t_id < worker_count; t_id++) {
		pthread_create(&handles[t_id],NULL,threadFunc,&param[t_id]);
	}

	for (int t_id = 0; t_id < worker_count; t_id++) {
		pthread_join(handles[t_id],NULL);
	}
	}
	gettimeofday(&tv_end,NULL);
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
		cout<<ma[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<"time:"<<(tv_end.tv_sec - tv_begin.tv_sec)<<endl; 
}
