#include<iostream>
#include <pthread.h>
#include<semaphore.h>
#include<stdio.h>
#include<stdlib.h>
#include <unistd.h>
#include<sys/time.h>
using namespace std;
typedef struct {
	 int t_id; //线程 id
}threadParam_t;

//信号量定义
sem_t sem_main;
sem_t sem_workerstart;
sem_t sem_workerend;

//常量
int n;
double** ma;
int NUM_THREADS = 10;//线程数
timeval tv_begin,tv_end;//record start and end time
void* threadFunc(void* param) {
	threadParam_t* p = (threadParam_t*)param;
	int t_id = p->t_id;

	for (int k = 0; k < n; ++k) {
	
		sem_wait(&sem_workerstart);
		cout<<"t "<<t_id<<endl;
		for (int i = k + 1 + t_id; i < n; i += NUM_THREADS) {
			for (int j = k + 1; j < n; j++) {
				ma[i][j] = ma[i][j] - ma[i][j] * ma[k][j];
			}
			ma[i][k] = 0;
		}
		sem_post(&sem_main); // 唤醒主线程
		cout<<t_id<<" wake main"<<endl;
		sem_wait(&sem_workerend); //阻塞，等待主线程唤醒进入下一轮
		sleep(0.0005);
		cout<<t_id<<" sleep"<<endl;
	}
	pthread_exit(NULL);
}
void init(){
	cin>>n;
	ma = new double*[n];
	for(int i=0;i<n;i++){
		ma[i] = new double[n];
	}
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++){
		cin>>ma[i][j];
		}
	cout<<"inputDone2"<<endl;
}
int main() {
	init();
	gettimeofday(&tv_begin,NULL);
	sem_init(&sem_main, 0, 0);
	sem_init(&sem_workerstart, 0, 0);
	sem_init(&sem_workerend, 0, 0);
	pthread_t handles[NUM_THREADS];// 创建对应的 Handle
	threadParam_t param[NUM_THREADS];// 创建对应的线程数据结构
	for (int t_id = 0; t_id < NUM_THREADS; t_id++) {
		param[t_id].t_id = t_id;
		pthread_create(&handles[t_id], NULL, threadFunc, &param[t_id]);
	}
	for (int k = 0; k < n; ++k) {
		for (int j = k + 1; j < n; j++) {
			ma[k][j] = ma[k][j] / ma[k][k];
		}
		ma[k][k] = 1;


		for (int t_id = 0; t_id < NUM_THREADS; ++t_id) {
			sem_post(&sem_workerstart);
		}

		for (int t_id = 0; t_id < NUM_THREADS; ++t_id) {
			sem_wait(&sem_main);
		}
		for (int t_id = 0; t_id < NUM_THREADS; ++t_id) {
			sem_post(&sem_workerend);
		}

	}
		for (int t_id = 0; t_id < NUM_THREADS; t_id++) {
			pthread_join(handles[t_id],NULL);
		}
		sem_destroy(&sem_main);
		sem_destroy(&sem_workerstart);
		sem_destroy(&sem_workerend);
	gettimeofday(&tv_end,NULL);
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
		cout<<ma[i][j]<<" ";
		}
		cout<<endl;
	}
	    cout<<"time:"<<(tv_end.tv_usec - tv_begin.tv_usec)<<endl; 
}
