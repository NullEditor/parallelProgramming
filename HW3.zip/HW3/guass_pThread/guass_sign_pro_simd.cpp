#include<iostream>
#include <pthread.h>
#include<semaphore.h>
#include <unistd.h>
#include<sys/time.h>
#include <arm_neon.h>
#include <fstream>
#include<sstream>
using namespace std;
typedef struct {
	int t_id; //线程 id
}threadParam_t;

//信号量定义
const int NUM_THREADS = 10;//线程数
sem_t sem_leader;
sem_t sem_Divsion[NUM_THREADS-1];
sem_t sem_Elimination[NUM_THREADS-1];

//常量
int n;
float** ma;

timeval tv_begin, tv_end;//record start and end time
void* threadFunc(void* param) {
	threadParam_t* p = (threadParam_t*)param;
	int t_id = p->t_id;

	for (int k = 0; k < n; k++) {
		if (t_id == 0) {
			int j = k + 1;
			float32x4_t vt = vdupq_n_f32(ma[k][k]);
			for (j; j+4 < n; j+=4) {
				float32x4_t va = vld1q_f32(*(ma + k) + j);
				float32x4_t reciprocal = vrecpeq_f32(vt);
				reciprocal = vmulq_f32(vrecpsq_f32(vt, reciprocal), 							reciprocal);//高精度倒数

				va = vmulq_f32(va, reciprocal);
				vst1q_f32(*(ma + k) + j, va);

			}
			for (j; j < n; j++) {
				ma[k][j] = ma[k][j] / ma[k][k];
			}
			ma[k][k] = 1;
		}
		else {
			sem_wait(&sem_Divsion[t_id-1]);
		}

		if (t_id == 0) {
			for (int i = 0; i < NUM_THREADS - 1; ++i) {
				sem_post(&sem_Divsion[i]);
			}
		}

		for (int i = k + 1 + t_id; i < n; i += NUM_THREADS) {
			int j = k + 1;
			float32x4_t vaik = vdupq_n_f32(ma[i][k]);
			for (j; j+4 < n; j+=4) {
			//ma[i][j] = ma[i][j] - ma[i][k] * ma[k][j];
				
				float32x4_t vakj = vld1q_f32(*(ma + k) + j);
				float32x4_t vaij = vld1q_f32(*(ma + i) + j);
				float32x4_t vx = vmulq_f32(vakj, vaik);
				float32x4_t neg = { -1,-1,-1,-1 };
				vaij = vmlaq_f32(vaij, neg, vx);

				vst1q_f32(*(ma + i) + j, vaij);
			}
			for (j; j < n; j++) {
				ma[i][j] = ma[i][j] - ma[i][k] * ma[k][j];
			}
			ma[i][k] = 0;
		}

		if (t_id == 0) {
			for (int i = 0; i < NUM_THREADS-1; ++i) {
				sem_wait(&sem_leader);
			}
			for (int i = 0; i < NUM_THREADS-1; ++i){
				sem_post(&sem_Elimination[i]);
			}
		}
		else {
			sem_post(&sem_leader);
			sem_wait(&sem_Elimination[t_id-1]);
		}
	}
	pthread_exit(NULL);
}
void fileInit(){
	ifstream file;
	file.open("data.txt");
	 if (! file.is_open())
   	 { cout << "Error opening file"; exit (1); }
   	 cout<<"openFile"<<endl;
   	char num[256];
   	file.getline(num,256);
   	stringstream ss(num);
   	ss>>n; 
   	cout<<n<<endl;
	ma = new float*[n];
	for(int i=0;i<n;i++){
		ma[i] = new float[n];
	}
	for(int i=0;i<n;i++){
		char line[1000];
		file.getline(line,1000);
		stringstream ss(line);
		for(int j=0;j<n;j++){
			ss>>ma[i][j];
		}
	}
	file.close();
}
void cinInit(){
	cin>>n;
	ma = new float*[n];
	for(int i=0;i<n;i++){
		ma[i] = new float[n];
	}
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++){
		cin>>ma[i][j];
		}
}
int main() {
	fileInit();
	gettimeofday(&tv_begin, NULL);
	sem_init(&sem_leader, 0, 0);
	for (int i = 0; i < NUM_THREADS-1; ++i){
	sem_init(&sem_Divsion[i], 0, 0);
	sem_init(&sem_Elimination[i], 0, 0);
	}

	pthread_t handles[NUM_THREADS];// 创建对应的 Handle
	threadParam_t param[NUM_THREADS];// 创建对应的线程数据结构
	for (int t_id = 0; t_id < NUM_THREADS; t_id++) {
		param[t_id].t_id = t_id;
		pthread_create(&handles[t_id], NULL, threadFunc, &param[t_id]);
	}
	for (int t_id = 0; t_id < NUM_THREADS; t_id++) {
		pthread_join(handles[t_id], NULL);
	}

	for (int i = 0; i < NUM_THREADS-1; ++i){
		sem_destroy(&sem_Divsion[i]);
		sem_destroy(&sem_Elimination[i]);
	}

	sem_destroy(&sem_leader);
	gettimeofday(&tv_end, NULL);
	/*
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			cout << ma[i][j] << " ";
		}
		cout << endl;
	}
	*/
	cout << "time:" << (tv_end.tv_sec - tv_begin.tv_sec) << endl;
}
