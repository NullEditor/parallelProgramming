#include <pthread.h>
#include <stdio.h>  
#include <stdlib.h>
#include<iostream>
#include<unistd.h>
#include<string>
using namespace std;
//由其他类型指针转换为void时不需要强制类型转换，但是从void到其他类型需要
class Node{
public:
int pid;
string str;
Node(int p,string s){
pid = p;
str = s;
}
};

void* printHello(void* argo){
	sleep(2);
	Node *arg = (Node*)argo;
	cout<<"This is id"<<arg->pid<<" Says: "<<arg->str<<endl;
	int *res = new int;
	*res = 999;
	pthread_exit(res);
	cout<<"not yet";
	return NULL;
}

int main(){
pthread_t p_1;
Node* firstOne = new Node(1,"i'm here");
pthread_create(&p_1,NULL,printHello,firstOne);
sleep(1);
//##pthread_cancel(p_1);
void* reso;
pthread_join(p_1,&reso);
int* res = (int*)reso;
cout<<"DONE,"<<"I get this: "<<*res;
return 0;
}
