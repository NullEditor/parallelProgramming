#include<iostream>
#include<semaphore.h>
#include<sys/time.h>
#include<unistd.h>
#include <fstream>
#include<sstream>
using namespace std;
//常量
int n;
double** ma;

timeval tv_begin,tv_end;//record start and end time
//输入方式
void fileInit(){
	ifstream file;
	file.open("data.txt");
	 if (! file.is_open())
   	 { cout << "Error opening file"; exit (1); }
   	 cout<<"openFile"<<endl;
   	char num[256];
   	file.getline(num,256);
   	stringstream ss(num);
   	ss>>n; 
   	cout<<n<<endl;
	ma = new double*[n];
		for(int i=0;i<n;i++){
		ma[i] = new double[n];
	}
	for(int i=0;i<n;i++){
		char line[1000];
		file.getline(line,1000);
		stringstream ss(line);
		for(int j=0;j<n;j++){
			ss>>ma[i][j];
		}
	}
	file.close();
}
void cinInit(){
	cin>>n;
	ma = new double*[n];
	for(int i=0;i<n;i++){
		ma[i] = new double[n];
	}
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++){
		cin>>ma[i][j];
		}
}

int main(){
	fileInit();
	gettimeofday(&tv_begin,NULL);
	int i,j,k,tmp;
	for(k = 0; k < n; ++k){
		tmp = ma[k][k];
		for(j = k + 1; j < n; ++j){
		ma[k][j] = ma[k][j] / tmp;
		}
		ma[k][k] = 1.0;
		}
		for(i = k + 1; i < n; ++i){
		tmp = ma[i][k];
		for(j = k + 1; j < n; ++j){
		ma[i][ j ] = ma[i][j] - tmp * ma[k][j];
		}
	}
	gettimeofday(&tv_end,NULL);
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
		cout<<ma[i][j]<<" ";
		}
		cout<<endl;
		}
	cout<<"time:"<<(tv_end.tv_usec - tv_begin.tv_usec)<<endl; 
}
