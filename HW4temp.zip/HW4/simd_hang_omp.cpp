#include <iostream>
#include <iomanip>
#include <fstream>
#include<sys/time.h>
#include<unistd.h>
#include <algorithm>
#include <string>
#include <arm_neon.h>
#include <cstdio>
#include <unistd.h> //对系统API操作
#include<sstream>
using namespace std;
//常量
int n;
float** ma;
const int NUM_THREADS = 10;//线程数

timeval tv_begin,tv_end;//record start and end time
//输入方式
void fileInit(){
	ifstream file;
	file.open("data.txt");
	 if (! file.is_open())
   	 { cout << "Error opening file"; exit (1); }
   	 cout<<"openFile"<<endl;
   	char num[256];
   	file.getline(num,256);
   	stringstream ss(num);
   	ss>>n; 
   	cout<<n<<endl;
	ma = new float*[n];
		for(int i=0;i<n;i++){
		ma[i] = new float[n];
	}
	for(int i=0;i<n;i++){
		char line[1000];
		file.getline(line,1000);
		stringstream ss(line);
		for(int j=0;j<n;j++){
			ss>>ma[i][j];
		}
	}
	file.close();
}
void cinInit(){
	cin>>n;
	ma = new float*[n];
	for(int i=0;i<n;i++){
		ma[i] = new float[n];
	}
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++){
		cin>>ma[i][j];
		}
}

int main(){
	fileInit();
	gettimeofday(&tv_begin,NULL);
	#pragma omp parallel if(parallel), num_threads(NUM_THREADS), private(i, j, k, tmp)
	int i,j,k,tmp;
	for(k = 0; k < n; ++k){
		#pragma omp single
		{
		float32x4_t vt = vdupq_n_f32(ma[k][k]);
		for(j = k + 1; j < n; ++j){
			float32x4_t va = vld1q_f32(*(ma + k) + j);
			float32x4_t reciprocal = vrecpeq_f32(vt);
			reciprocal = vmulq_f32(vrecpsq_f32(vt, reciprocal), 							reciprocal);//高精度倒数

			va = vmulq_f32(va, reciprocal);
			vst1q_f32(*(ma + k) + j, va);
		}
		for (j; j < n; j++) {
			ma[k][j] = ma[k][j] / ma[k][k];
		}
		ma[k][k] = 1.0;
		}
		// 并行部分，使用行划分
		#pragma omp for
		for(i = k + 1; i < n; ++i){
		float32x4_t vaik = vdupq_n_f32(ma[i][k]);
		for(j = k + 1; j < n; ++j){
			float32x4_t vakj = vld1q_f32(*(ma + k) + j);
			float32x4_t vaij = vld1q_f32(*(ma + i) + j);
			float32x4_t vx = vmulq_f32(vakj, vaik);
			float32x4_t neg = { -1,-1,-1,-1 };
			vaij = vmlaq_f32(vaij, neg, vx);
			vst1q_f32(*(ma + i) + j, vaij);
		}
		for (j; j < n; j++) {
			ma[i][j] = ma[i][j] - ma[i][k] * ma[k][j];
		}
			ma[i][k] = 0;
		ma[i][k] = 0;
		}
		// 离开for循环时，各个线程默认同步，进入下一行的处理
	}
	gettimeofday(&tv_end,NULL);
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
		cout<<ma[i][j]<<" ";
		}
		cout<<endl;
		}
	cout<<"time:"<<(tv_end.tv_usec - tv_begin.tv_usec)<<endl; 
}
