#include<iostream>
#include<omp.h>
#include<vector>
using namespace std;

const int NUM_THREADS = 5;

int main(){
	int n;
	cin>>n;
	vector<vector<int>> mat;
	for(int i=0;i<n;i++){
		vector<int> temp;
		for(int j=0;j<n;j++){
			int a;
			cin>>a;
			temp.push_back(a);
		}
		mat.push_back(temp);
	}
	
	#pragma omp parallel num_threads(NUM_THREADS),private(i,j,k,tmp)
	int i,j,k,tmp;
	for(k = 0; k < n; ++k){
		// 串行部分，也可以尝试并行化
		#pragma omp single
		{
		tmp = mat[k][k];
		for(j = k + 1; j < n; ++j){
		mat[k][j] = mat[k][j] / tmp;
		}
		mat[k][k] = 1;
		}
		// 并行部分，使用行划分
		#pragma omp for
		for(i = k + 1; i < n; ++i){
		tmp = mat[i][k];
		for(j = k + 1; j < n; ++j){
		mat[i][ j ] = mat[i][j] - tmp * mat[k][j];
		}
		mat[i][k] = 0;
		cout<<"llll"<<endl;
		}
		// 离开for循环时，各个线程默认同步，进入下一行的处理
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
		cout<<mat[i][j]<<" ";
		}
		cout<<endl;
		}
}
