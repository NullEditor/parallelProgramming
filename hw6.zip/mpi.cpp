#include<iostream>
#include<semaphore.h>
#include<sys/time.h>
#include<unistd.h>
#include <fstream>
#include<sstream>
#include<cmath>
#include"mpi.h"
using namespace std;
//常量
int n;
float** ma;

timeval tv_begin,tv_end;//record start and end time

//输入方式
void fileInit(){
	ifstream file;
	file.open("data.txt");
	 if (! file.is_open())
   	 { cout << "Error opening file"; exit (1); }
   	char num[256];
   	file.getline(num,256);
   	stringstream ss(num);
   	ss>>n; 
	ma = new float*[n];
		for(int i=0;i<n;i++){
		ma[i] = new float[n];
	}
	for(int i=0;i<n;i++){
		char line[1000];
		file.getline(line,1000);
		stringstream ss(line);
		for(int j=0;j<n;j++){
			ss>>ma[i][j];
		}
	}
	file.close();
}
void cinInit(){
	cin>>n;
	ma = new float*[n];
	for(int i=0;i<n;i++){
		ma[i] = new float[n];
	}
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++){
		cin>>ma[i][j];
		}
}


int main(){
	fileInit();
	gettimeofday(&tv_begin,NULL);
	////////////////////////////////////////////////////////////////////
	int myid,numprocs;
	cout<<"ready"<<endl;
	MPI_Init(0,0);
	MPI_Comm_rank(MPI_COMM_WORLD, &myid); //获取当前进程号
  	MPI_Comm_size(MPI_COMM_WORLD, &numprocs); //获取进程总数
  	MPI_Status status;
  	int start,end;//分配每个进程的任务
  	if(myid<numprocs-1){
  		start = myid * (n - n%numprocs)/numprocs;
  		end =  myid * (n - n%numprocs)/numprocs + (n - n%numprocs)/numprocs - 1;
  	}
  	else{
  		start = (numprocs - 1) * (n - n%numprocs)/numprocs;
  		end =  n - 1;
  	}
	int i,j,k;
	for(k = 0; k < n; ++k){
		if(start<=k&&k<=end){//如果在自己划分的范围内,进行除法
			for(j=k+1;j<n;j++){
				ma[k][j] = ma[k][j]/ma[k][k];
			}
			ma[k][k]=1.0;
			for(j=0;j<numprocs;j++){
				if(j!=myid)
					MPI_Send(&ma[k][0],n,MPI_FLOAT,j,k,MPI_COMM_WORLD);
					//cout<<myid<<" send"<<endl;
			}
		}
		else{
			MPI_Recv(&ma[k][0],n,MPI_FLOAT,MPI_ANY_SOURCE,k,MPI_COMM_WORLD,&status);
			//cout<<myid<<" recv"<<endl;
			
		}
		//int startLine = max(k,start);
		for(i=start;i<=end;i++){
			if(start<=k)
				continue;
			for(j=k+1;j<n;j++){
				ma[i][j] = ma[i][j] - ma[k][j]*ma[i][k];
			}
			ma[i][k]=0;
		}
	}


	//////////////////////////////////////////////////////////////////
	gettimeofday(&tv_end,NULL);
	if(myid==0){
			for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
		cout<<ma[i][j]<<" ";
		}
		cout<<endl;
		}
	cout<<"time:"<<(tv_end.tv_usec - tv_begin.tv_usec)<<endl; 
	}

	MPI_Finalize();
}
